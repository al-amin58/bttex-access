<script setup>

</script>

<template>
<div class="info-alert">
    <div class="info-alert-icon">
        <i class="bi bi-info-circle"></i>
    </div>
    <div class="info-alert-text">
        <p> You have the flexibility to utilize SVGs from various sources, but we suggest using SVGs from <a
            href="https://icones.js.org/" target="_blank" class="primary-color">https://icones.js.org/</a> for optimal results.</p>
    </div>
</div>
</template>

<style scoped>

</style>
