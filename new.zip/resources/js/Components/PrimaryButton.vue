<template>
    <button
        class="button-primary"
    >
        <slot />
    </button>
</template>
