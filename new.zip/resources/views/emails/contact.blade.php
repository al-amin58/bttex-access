<div style="background-color: #fff">
    <h2>Contact Message</h2>
    <div>
        <p>Name: {{ $name }}</p>
        <p>Phone: {{ $phone }}</p>
        <p>Email: {{ $email }}</p>
        <p>Message: {{ $body }} </p>
        <p>Company Name: {{ $companyName }}</p>
        <p>Company Detail: {{ $companyName }}</p>
    </div>
</div>
